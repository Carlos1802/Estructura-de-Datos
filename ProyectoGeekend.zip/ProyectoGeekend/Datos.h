#pragma once

#include <iostream>
using namespace std;

class Datos
{
public:
	int edad;
	char ocupacion[30];
	char sexo[30];

	Datos(void);
	~Datos(void);
};

