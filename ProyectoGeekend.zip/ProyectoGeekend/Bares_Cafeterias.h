#pragma once

#include <iostream>
using namespace std;

class Bares_Cafeterias
{
public:
	Bares_Cafeterias(void);
	~Bares_Cafeterias(void);

	void BaresCafes();
};

