#include "StdAfx.h"
#include "LugaresTuristicos.h"


LugaresTuristicos::LugaresTuristicos(void)
{
}


LugaresTuristicos::~LugaresTuristicos(void)
{
}

void LugaresTuristicos::LugaresT()
{
	int opcion;

	do{
		cout<<"Bienvenido a la Seccion de Lugares Turisticos de Santa Cruz de la Sierra."<<endl;
		cout<<"Seleccione una opcion para ver su respectiva informacion."<<endl;
		cout<<endl;
		cout<<"1. Catedral Basilica de San Lorenzo."<<endl;
		cout<<"2. Zoologico Municipal de Fauna Sudamericana Noel Kempff Mercado."<<endl;
		cout<<"3. Parque El Arenal."<<endl;
		cout<<"4. Parque Urbano."<<endl;
		cout<<"5. Jardin Botanico de Santa Cruz de la Sierra."<<endl;
		cout<<"6. Plaza 24 de Septiembre."<<endl;
		cout<<"7. Manzana Uno."<<endl;
		cout<<"8. Casa Cultural Melchor Pinto."<<endl;
		cout<<"9. Parque Urbano de Preservacion Ecologica Curichi La Madre."<<endl;
		cout<<"10. Museo de la Independencia."<<endl;
		cout<<"0. Volver."<<endl;
		cin>>opcion;
		system("cls");

		switch(opcion)
		{

		case 1:
			cout<<"___	Catedral Basilica de San Lorenzo	___"<<endl;
			cout<<endl;
			cout<<"Descripcion: Principal Templo Catolico de Santa Cruz de la Sierra. Cuenta con un"<<endl;
			cout<<"mirador ubicado en una de sus torres. Ademas de tener un Museo de Arte Sacro "<<endl;
			cout<<"con obras que datan desde los inicios de la Iglesia Catolica."<<endl;
			cout<<endl;
			cout<<"Direccion: Frente a la Plaza 24 de Septiembre."<<endl;
			cout<<"Horario de Atencion: Lunes a Viernes de 08:00 a 16:00."<<endl;
			cout<<"Telefono: 3324683."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 2:
			cout<<"___	Zoologico Municipal de Fauna Sudamericana Noel Kempff Mercado	___"<<endl;
			cout<<endl;
			cout<<"Descripcion: Considerado como el zoologico mas importante de Bolivia y America"<<endl;
			cout<<"del Sur por su extensa biodiversidad de especies autoctonas."<<endl;
			cout<<endl;
			cout<<"Direccion: 3er Anillo Interno Radial 27."<<endl;
			cout<<"Horario de Atencion: Martes a Domingo de 09:00 a 17:30."<<endl;
			cout<<"Telefono: 3429939."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 3:
			cout<<"___	Parque El Arenal	___"<<endl;
			cout<<endl;
			cout<<"Descripcion: Un retazo de la ciudad lleno de hondas reminiscencias para los"<<endl;
			cout<<"crucenhos dado que es una de las primeras zonas de esparcimiento publico"<<endl;
			cout<<"de la ciudad."<<endl;
			cout<<endl;
			cout<<"Direccion: Zona Central de Santa Cruz de la Sierra."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 07:00 a 21:00."<<endl;
			cout<<"Telefono: ----"<<endl;
			cout<<endl;
			break;
			system("cls");

		case 4:
			cout<<"___	Parque Urbano	___"<<endl;
			cout<<endl;
			cout<<"Descripcion: Una de las pocas areas verdes que se han logrado preservar en"<<endl;
			cout<<"las proximidades al centro de la ciudad. Es un area de esparcimiento que"<<endl;
			cout<<"cuenta con equipamiento para la realizacion de ejercicios y como centro de"<<endl;
			cout<<"realizacion de distintos eventos en la ciudad."<<endl;
			cout<<endl;
			cout<<"Direccion: Av. 3 Pasos al Frente y 2do Anillo."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 08:00 a 24:00."<<endl;
			cout<<"Telefono: ----"<<endl;
			cout<<endl;
			break;
			system("cls"); 

		case 5:
			cout<<"___	Jardin Botanico de Santa Cruz de la Sierra	___"<<endl;
			cout<<endl;
			cout<<"Descripcion:Con el prop�sito de conservar y exhibir la gran diversidad flor�stica,"<<endl;
			cout<<"vegetal y animal de Santa Cruz, el nuevo Jard�n Bot�nico se proyecta como una"<<endl;
			cout<<"referencia ecol�gica, �nica que debe contar con el apoyo de todos los amigos"<<endl;
			cout<<"de la Naturaleza."<<endl;
			cout<<endl;
			cout<<"Direccion: Carretera a Cotoca Km 8."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 08:00 a 17:00."<<endl;
			cout<<"Telefono: 3623101."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 6:
			cout<<"___	Plaza 24 de Septiembre	___"<<endl;
			cout<<endl;
			cout<<"Descripcion: Centro historico de la ciudad, fue testigo de las primeras edificaciones"<<endl;
			cout<<"ademas de distintos sucesos historicos en la ciudad."<<endl;
			cout<<endl;
			cout<<"Direccion: Centro de la Ciudad."<<endl;
			cout<<"Horario de Atencion: Todos los dias."<<endl;
			cout<<"Telefono: ----"<<endl;
			cout<<endl;
			break;
			system("cls");

		case 7:
			cout<<"___	Manzana Uno	___"<<endl;
			cout<<endl;
			cout<<"Descripcion: Area cultural donde se puede apreciar ditintas expresiones de la"<<endl;
			cout<<"cultura crucenha."<<endl;
			cout<<endl;
			cout<<"Direccion: Atras de la Catedral Basilica de San Lorenzo."<<endl;
			cout<<"Horario de Atencion: Todos los dias."<<endl;
			cout<<"Telefono: ----"<<endl;
			cout<<endl;
			break;
			system("cls");

		case 8:
			cout<<"___	Casa Cultural Melchor Pinto	___"<<endl;
			cout<<endl;
			cout<<"Descripcion: Lugar de gran significado para la crucenhidad dado que era hogar de"<<endl;
			cout<<"Melchor Pinto. Actualmente es un centro donde se puede apreciar distintas expresiones"<<endl;
			cout<<"culturales tipicas de la ciudad."<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Sucre Nro 50."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 08:00 a 20:00."<<endl;
			cout<<"Telefono: 3323082."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 9:
			cout<<"___	Parque Urbano de Preservacion Ecologica Curichi La Madre	___"<<endl;
			cout<<endl;
			cout<<"Descripcion: Parque protegido donde se puede apreciar distintas clases de flora y fauna"<<endl;
			cout<<"tipica de Santa Cruz."<<endl;
			cout<<endl;
			cout<<"Direccion: Final Av. Roca y Coronado."<<endl;
			cout<<"Horario de Atencion: Lunes a Viernes de 08:00 a 19:00."<<endl;
			cout<<"Telefono: 77829697."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 10:
			cout<<"___	Museo de la Independencia	___"<<endl;
			cout<<endl;
			cout<<"Descripcion: En esta casa fue declarada la Independencia de Santa Cruz durante las rebeliones"<<endl;
			cout<<"en contra de la corona espanhola."<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Ayacucho esquina Libertad."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 09:00 a 12:00 y 15:00 a 19:00."<<endl;
			cout<<"Telefono: 75595484."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 0:
			cout<<"Volviendo."<<endl;
			system("cls");
			break;

		default:
			cout<<"Opcion Erronea."<<endl;
			cout<<endl;
		}
	}while(opcion!=0);
}
