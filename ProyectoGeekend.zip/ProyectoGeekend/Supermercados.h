#pragma once

#include <iostream>
using namespace std;

class Supermercados
{
public:
	Supermercados(void);
	~Supermercados(void);

	void SuperM();
};

