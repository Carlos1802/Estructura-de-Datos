#include "StdAfx.h"
#include "Bares_Cafeterias.h"


Bares_Cafeterias::Bares_Cafeterias(void)
{
}


Bares_Cafeterias::~Bares_Cafeterias(void)
{
}

void Bares_Cafeterias::BaresCafes()
{
	int opcion;

	do{
		cout<<"Bienvenido a la Seccion de Bares y Cafeterias."<<endl;
		cout<<"Elija una opcion."<<endl;
		cout<<endl;
		cout<<"1. Cafe Patrimonio."<<endl;
		cout<<"2. Cafeteria Mi Cafe."<<endl;
		cout<<"3. Cafeteria Wistupiku."<<endl;
		cout<<"4. Alenxander Coffee."<<endl;
		cout<<"5. Meraki Teatro Bar."<<endl;
		cout<<"6. The Dubliner Irish Pub & Restaurante."<<endl;
		cout<<"7. Factory Grill & Bar."<<endl;
		cout<<"0. Volver."<<endl;
		cin>>opcion;
		system("cls");

		switch(opcion)
		{
		case 1:
			cout<<"___	Cafe Patrimonio	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Sucre Nro 50."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 08:00 a 23:00."<<endl;
			cout<<"Telefono: 70007000."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 2:
			cout<<"___Cafeteria Mi Cafe	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Tarija y 1er Anillo."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 15:00 a 20:15."<<endl;
			cout<<"Telefono: 77345876."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 3:
			cout<<"___	Cafeteria Wistupiku	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle 24 de Septiembre casi 1er Anillo."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 07:00 a 11:00 y de 16:00 a 21:00."<<endl;
			cout<<"Telefono: 3239800."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 4:
			cout<<"___	Alexander Coffee	___"<<endl;
			cout<<endl;
			cout<<"Direccion Av. Mosenhir Rivero casi 2do Anillo."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 07:00 a 23:00."<<endl;
			cout<<"Telefono: 3378653."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 5:
			cout<<"___	Meraki Teatro Bar	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Ballivian Nro 159."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 18:00 a 03:00."<<endl;
			cout<<"Telefono: 77055939."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 6:
			cout<<"___	The Dubliner Irish Pub y Restaurante	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Planta Alta Cine Center."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 12:00 a 03:00."<<endl;
			cout<<"Telefono: 3358181."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 7:
			cout<<"___	Factory Grill & Bar	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Av. Velarde esquina  Calle Juan de Garay."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 12:00 a 23:30."<<endl;
			cout<<"Telefono: 3364300."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 0:
			cout<<"Volviendo."<<endl;
			system("cls");
			break;

		default:
			cout<<"Opcion Erronea."<<endl;
			cout<<endl;
		}
	}while(opcion!=0);
}