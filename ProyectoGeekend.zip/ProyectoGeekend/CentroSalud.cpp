#include "StdAfx.h"
#include "CentroSalud.h"


CentroSalud::CentroSalud(void)
{
}


CentroSalud::~CentroSalud(void)
{
}

void CentroSalud::CentroS()
{
	int opcion;

	do{
		cout<<"Bienvenido a la Seccion de Centros de Salud."<<endl;
		cout<<"Todos los hospitales atienden las 24 horas del dia durante toda la semana."<<endl;
		cout<<"Usted solamente debe aproximarse a la zona de emergencias para ser atendido."<<endl;
		cout<<"Elija una de las opciones."<<endl;
		cout<<endl;
		cout<<"1. Hospital San Juan de Dios."<<endl;
		cout<<"2. Hospital Universitario Japones."<<endl;
		cout<<"3. Hospital Municipal Villa 1ro de Mayo."<<endl;
		cout<<"4. Hospital de la Mujer Dr. Percy Boland."<<endl;
		cout<<"5. Hospital de Nihos Dr. Mario Ortiz Suarez."<<endl;
		cout<<"6. Caja Nacional de Salud Hospital Obrero Nro 3."<<endl;
		cout<<"7. Hospital Caja Petrolera."<<endl;
		cout<<"8. Hospital Municipal Frances."<<endl;
		cout<<"0. Volver."<<endl;
		cin>>opcion;
		system("cls");

		switch(opcion)
		{
		case 1:
			cout<<"___	Hospital San Juan de Dios	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Cuellar."<<endl;
			cout<<"Telefono: 3332222."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 2:
			cout<<"___	Hospital Universitario Japones	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Av. Dr. Luca Saucedo."<<endl;
			cout<<"Telefono: 3462030."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 3:
			cout<<"___	Hospital Municipal Villa 1ro de Mayo	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Av. 3 Pasos al Frente 7mo Anillo."<<endl;
			cout<<"Telefono: 3328000."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 4:
			cout<<"___	Hospital de la Mujer Dr. Percy Boland	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Cuellar entre Calles Sara y Santa Barbara."<<endl;
			cout<<"Telefono: 3363522."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 5:
			cout<<"___	Hospital de Ninhos Dr. Mario Ortiz Suarez	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Santa Barbara esquina Buenos Aires."<<endl;
			cout<<"Telefono: 3371110."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 6:
			cout<<"___	Caja Nacional de Salud Hospital Obrero Nro3	___"<<endl;
			cout<<endl;
			cout<<"Direccion: 3er Anillo Interno entre Av. Mutualista y Av. Paragua."<<endl;
			cout<<"Telefono: 3471600."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 7:
			cout<<"___	Hospital Caja Petrolera	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Espa�a."<<endl;
			cout<<"Telefono: 3181600."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 8:
			cout<<"___	Hospital Municipal Frances	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Av. Santos Dumont 7mo Anillo Urb. Paititi."<<endl;
			cout<<"Telefono: 3518973."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 0:
			cout<<"Volviendo."<<endl;
			system("cls");
			break;

		default:
			cout<<"Opcion Erronea."<<endl;
			cout<<endl;

		}

	}while(opcion!=0);

}