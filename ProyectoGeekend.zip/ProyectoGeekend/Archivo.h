#pragma once

#include <iostream>
#include "Datos.h"
using namespace std;

class Archivo
{
public:
	Archivo(void);
	~Archivo(void);

	void crearArchivo(char nomA[15]);
	void pedirDatos(Datos *dato);
	void adicionarDatos(char nomA[15]);
};

