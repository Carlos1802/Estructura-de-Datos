#pragma once

#include <iostream>
using namespace std;

class LugaresTuristicos
{
public:
	LugaresTuristicos(void);
	~LugaresTuristicos(void);

	void LugaresT();
};

