#pragma once

#include <iostream>
using namespace std;


class Transporte
{
public:
	Transporte(void);
	~Transporte(void);

	void Taxi();
};

