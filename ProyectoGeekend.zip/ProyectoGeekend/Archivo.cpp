#include "StdAfx.h"
#include "Archivo.h"


Archivo::Archivo(void)
{
}


Archivo::~Archivo(void)
{
}

void Archivo::crearArchivo(char nomA[15])
{
	FILE *dat;
	dat = fopen(nomA,"wb");
	fclose(dat);
}

void Archivo::pedirDatos(Datos *dato)
{
	cout<<"Por favor ingrese sus datos."<<endl;
	cout<<endl;
	cout<<"Ingrese su edad."<<endl;
	cin>>dato->edad;
	cout<<endl;

	cout<<"Ingrese su ocupacion."<<endl;
	do{
		gets(dato->ocupacion);
	}while(strlen(dato->ocupacion)==0);
	
	cout<<endl;

	cout<<"Ingrese su sexo."<<endl;
	do{
		gets(dato->sexo);
	}while(strlen(dato->sexo)==0);

	system("cls");
}

void Archivo::adicionarDatos(char nomA[15])
{
	FILE *dat;
	Datos dato;
	dat = fopen(nomA,"ab");
	pedirDatos(&dato);
	fwrite(&dato,sizeof(class Datos),1,dat);
	fclose(dat);
}
