
#include "stdafx.h"
#include <iostream>
#include "conio.h"
#include "Archivo.h"
#include "Supermercados.h"
#include "CentroSalud.h"
#include "LugaresTuristicos.h"
#include "Bares_Cafeterias.h"
#include "CentrosComerciales.h"
#include "Transporte.h"

using namespace std;

void main()
{
	int opcion;

	Archivo a1;
	LugaresTuristicos l1;
	Supermercados s1;
	CentroSalud h1;
	Bares_Cafeterias b1;
	CentrosComerciales c1;
	Transporte t1;



	cout<<"___	GEEKEND	___"<<endl;
	cout<<"Bienvenido a la Guia Turistica de Santa Cruz de la Sierra."<<endl;
	cout<<endl;

	//a1.crearArchivo("DatosU.dat");
	a1.adicionarDatos("DatosU.dat");

	do{
		cout<<"___	GEEKEND	___"<<endl;
		cout<<"Bienvenido a la Guia Turistica de Santa Cruz de la Sierra."<<endl;
		cout<<endl;
		cout<<"Elija una de las opciones."<<endl;
		cout<<endl;
		cout<<"1. Lugares Turisticos."<<endl;
		cout<<"2. Bares y Cafeterias."<<endl;
		cout<<"3. Centros Comerciales."<<endl;
		cout<<"4. Supermercados."<<endl;
		cout<<"5. Centros de Salud."<<endl;
		cout<<"6. Transporte."<<endl;
		cout<<"0. Salir."<<endl;
		cin>>opcion;
		system("cls");

		switch(opcion)
		{
		case 1:
			l1.LugaresT();
			break;

		case 2:
			b1.BaresCafes();
			break;

		case 3:
			c1.CentrosC();
			break;

		case 4:
			s1.SuperM();
			break;

		case 5:
			h1.CentroS();
			break;

		case 6:
			t1.Taxi();
			break;

		case 0:
			cout<<"Gracias por usar la aplicacion."<<endl;
			cout<<"Saliendo."<<endl;
			break;

		default:
			cout<<"Opcion Erronea."<<endl;
		}

	}while(opcion!=0);
	
	getch();
}

