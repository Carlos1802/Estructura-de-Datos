#include "StdAfx.h"
#include "Supermercados.h"


Supermercados::Supermercados(void)
{
}


Supermercados::~Supermercados(void)
{
}

void Supermercados::SuperM()
{
	int opcion, hipermaxi, tia, fidalga;

	do{
		cout<<"Bienvenido a la Seccion de Supermercados."<<endl;
		cout<<"Elija una Linea de Supermercados."<<endl;
		cout<<endl;
		cout<<"1. Hipermaxi."<<endl;
		cout<<"2. Supermercados Tia."<<endl;
		cout<<"3. Fidalga."<<endl;
		cout<<"4. IC Norte."<<endl;
		cout<<"5. Makro Parque."<<endl;
		cout<<"0. Volver."<<endl;
		cin>>opcion;
		system("cls");

		switch(opcion)
		{

		case 1:
			do{
				cout<<"___	Hipermaxi	___"<<endl;
				cout<<endl;
				cout<<"1. Sucursal Norte."<<endl;
				cout<<"2. Sucursal Sur."<<endl;
				cout<<"3. Sucursal Centro."<<endl;
				cout<<"4. Sucursal Florida."<<endl;
				cout<<"5. Sucursal Pirai."<<endl;
				cout<<"6. Sucursal Las Palmas."<<endl;
				cout<<"7. Sucursal 3 Pasos al Frente."<<endl;
				cout<<"0. Volver."<<endl;
				cin>>hipermaxi;
				system("cls");

				switch(hipermaxi)
				{

				case 1:
					cout<<"Sucursal Norte."<<endl;
					cout<<"Direccion: Av. Cristo Redentor y 3er Anillo Interno."<<endl;
					cout<<"Horario de Atencion: Todos los dias de 08:00 a 23:00."<<endl;
					cout<<"Telefono: 3425353."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 2:
					cout<<"Sucursal Sur."<<endl;
					cout<<"Direccion: Av. Santos Dumont y 3er Anillo Interno."<<endl;
					cout<<"Horario de Atencion: Todos los dias de 08:00 a 23:00."<<endl;
					cout<<"Telefono: 3471600."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 3:
					cout<<"Sucursal Centro."<<endl;
					cout<<"Direccion: Calle Manuel Ignacio Salvatierra."<<endl;
					cout<<"Horario de Atencion: Todos los dias de 10:00 a 24:00."<<endl;
					cout<<"Telefono: 3471450."<<endl;
					cout<<endl;
					break;
					system("cls");
					
				case 4:
					cout<<"Sucursal Florida."<<endl;
					cout<<"Direccion: Calle Florida Nro 174."<<endl;
					cout<<"Horario de Atencion: 10:00 a 24:00."<<endl;
					cout<<"Telefono: 3471098."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 5:
					cout<<"Sucursal Pirai."<<endl;
					cout<<"Direccion: Av. Pirai y 2do Anillo."<<endl;
					cout<<"Horario de Atencion: Todos los dias de 09:00 a 23:00."<<endl;
					cout<<"Telefono: 76611187."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 6:
					cout<<"Sucursal Las Palmas."<<endl;
					cout<<"Direccion: Av. Grigota y 4to Anillo."<<endl;
					cout<<"Horario de Atencion: Todos los dias de 09:00 a 22:00."<<endl;
					cout<<"Telefono: 3569800."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 7:
					cout<<"Sucursal 3 Pasos al Frente."<<endl;
					cout<<"Direccion: Av. 3 Pasos al Frente y 3er Anillo."<<endl;
					cout<<"Horario de Atencion: Todos los dias de 09:00 a 22:00."<<endl;
					cout<<"Telefono: 3257644."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 0:
					cout<<"Volviendo."<<endl;
					system("cls");
					break;

				default:
					cout<<"Opcion Erronea."<<endl;
					cout<<endl;
				}
			}while(hipermaxi!=0);
			cout<<endl;
			break;

		case 2:
			do{
				cout<<"___	Supermercados Tia	___"<<endl;
				cout<<endl;
				cout<<"1. Sucursal Centro."<<endl;
				cout<<"2. Sucursal Norte."<<endl;
				cout<<"3. Sucursal Ventura Mall."<<endl;
				cout<<"0. Volver."<<endl; 
				cin>>tia;
				system("cls");

				switch(tia)
				{
				case 1:
					cout<<"Sucursal Centro."<<endl;
					cout<<"Direccion: Calle 24 de Septiembre esquina Cuellar."<<endl;
					cout<<"Horario de Atencion: Todos los dias de 07:00 a 22:30."<<endl;
					cout<<"Telefono: 3375151."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 2:
					cout<<"Sucursal Norte."<<endl;
					cout<<"Direccion: Av. Alemania casi 4to Anillo."<<endl;
					cout<<"Horario de Atencion: Todos los dias de 09:00 a 22:00."<<endl;
					cout<<"Telefono: 3328766."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 3:
					cout<<"Sucursal Ventura Mall."<<endl;
					cout<<"Direccion: Planta Baja del Ventura Mall."<<endl;
					cout<<"Horario de Atencion: Todos los dias de 10:00 a 24:00."<<endl;
					cout<<"Telefono: 3457809."<<endl;
					cout<<endl;
					break;
					system("cls");
					
				case 0:
					cout<<"Volviendo."<<endl;
					system("cls");
					break;

				default:
					cout<<"Opcion Erronea."<<endl;
					cout<<endl;
				}
		
			}while(tia!=0);
			cout<<endl;
			break;

		case 3:
			do{
				cout<<"___	Fidalga	___"<<endl;
				cout<<endl;
				cout<<"1. Sucursal Trompillo."<<endl;
				cout<<"2. Sucursal Sur."<<endl;
				cout<<"3. Sucursal Reyes."<<endl;
				cout<<"4. Sucursal Ekko."<<endl;
				cout<<"5. Shopping Fidalga Equipetrol."<<endl;
				cout<<"6. Sucursal Macro."<<endl;
				cout<<"7. Hamacas."<<endl;
				cout<<"8. Shopping Fidalga Norte."<<endl;
				cin>>fidalga;
				system("cls");

				switch(fidalga)
				{
				case 1:
					cout<<"Sucursal Trompillo."<<endl;
					cout<<"Direccion: Av. Trompillo esquina Yacuiba."<<endl;
					cout<<"Horario: Todos los dias de 08:00 a 22:00."<<endl;
					cout<<"Telefono: 3517070."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 2:
					cout<<"Sucursal Sur."<<endl;
					cout<<"Direccion: Av. Rene Moreno Nro 212."<<endl;
					cout<<"Horario: Todos los dias de 10:00 a 23:00."<<endl;
					cout<<"Telefono: 3334144."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 3:
					cout<<"Sucursal Reyes."<<endl;
					cout<<"Direccion: Av. 26 de Febrero Nro 517."<<endl;
					cout<<"Horario: Todos los dias de 08:00 a 23:00."<<endl;
					cout<<"Telefono: 3541308."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 4:
					cout<<"Sucursal Ekko."<<endl;
					cout<<"Direccion: Av. Canhoto Nro 203."<<endl;
					cout<<"Horario: Todos los dias de 08:00 a 22:00."<<endl;
					cout<<"Telefono: 3363656."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 5:
					cout<<"Shopping Fidalga Equipetrol."<<endl;
					cout<<"Direccion: Av. Equipetrol y Fermin Peralta."<<endl;
					cout<<"Horario: Todos los dias de 10:00 a 24:00."<<endl;
					cout<<"Telefono: 3433838."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 6:
					cout<<"Sucursal Macro."<<endl;
					cout<<"Direccion: Av. Uruguay y General Velasco."<<endl;
					cout<<"Horario: Todos los dias de 09:00 a 22:00."<<endl;
					cout<<"Telefono: 3365757."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 7:
					cout<<"Sucursal Hamacas."<<endl;
					cout<<"Direccion: Av. Beni Nro 500."<<endl;
					cout<<"Horario: Todos los dias de 08:00 a 23:00."<<endl;
					cout<<"Telefono: 3452100."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 8:
					cout<<"Shopping Fidalga Norte."<<endl;
					cout<<"Direccion: Av. Banzer esquina Tercer Anillo."<<endl;
					cout<<"Horario: Todos los dias de 09:00 a 24:00."<<endl;
					cout<<"Telefono: 3249800."<<endl;
					cout<<endl;
					break;
					system("cls");

				case 0:
					cout<<"Volviendo."<<endl;
					system("cls");
					break;

				default:
					cout<<"Opcion Erronea."<<endl;
					cout<<endl;
				}
			}while(fidalga!=0);
			cout<<endl;
			break;

		case 4:
			cout<<"___	IC Norte	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Av. Busch y 3er Anillo Interno"<<endl;
			cout<<"Horario: Todos los dias de 09:00 a 22:30."<<endl;
			cout<<"Telefono: 3419606."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 5:
			cout<<"___	Makro Parque	___"<<endl;
			cout<<endl;

			cout<<"Direccion: Av. Paragua y 4to Anillo."<<endl;
			cout<<"Horario: Todos los dias de 08:00 a 23:00."<<endl;
			cout<<"Telefono: 3489999."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 0:
			cout<<"Volviendo."<<endl;
			system("cls");
			break;

		default:
			cout<<"Opcion Erronea."<<endl;
			cout<<endl;
		}
	}while(opcion!=0);
}