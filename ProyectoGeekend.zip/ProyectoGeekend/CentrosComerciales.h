#pragma once

#include <iostream>
using namespace std;

class CentrosComerciales
{
public:
	CentrosComerciales(void);
	~CentrosComerciales(void);

	void CentrosC();
};

