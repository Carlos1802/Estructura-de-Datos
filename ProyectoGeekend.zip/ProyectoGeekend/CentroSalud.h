#pragma once

#include <iostream>
using namespace std;

class CentroSalud
{
public:
	CentroSalud(void);
	~CentroSalud(void);
	
	void CentroS();
};

