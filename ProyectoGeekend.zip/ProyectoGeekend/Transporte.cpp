#include "StdAfx.h"
#include "Transporte.h"


Transporte::Transporte(void)
{
}


Transporte::~Transporte(void)
{
}

void Transporte::Taxi()
{
	int opcion, taxi;
	do{
		cout<<"Elija una opcion para la utilizacion de transporte."<<endl;
		cout<<endl;
		cout<<"1. Llamar Taxi."<<endl;
		cout<<"2. Cotizar tarifa."<<endl;
		cout<<"0. Volver."<<endl;
		cin>>opcion;
		system("cls");

		switch(opcion)
		{

		case 1:
			cout<<"Elija una empresa de Radio Taxi."<<endl;
			cout<<endl;
			cout<<"1. Radio Movil Paraba."<<endl;
			cout<<"2. Radio Movil Sombrero de Sao."<<endl;
			cout<<"3. Radio Movil Chuturubi."<<endl;
			cin>>taxi;
			system("cls");

			if(taxi==1 || taxi==2 || taxi==3)
				cout<<"Llamando Taxi..."<<endl;
			system("pause>NULL");
			break;

		case 2:
			cout<<"Llamando a Sindicato de Taxis 24 de Septiembre."<<endl;
			system("cls");
			break;

		case 0:
			cout<<"Volviendo."<<endl;
			system("cls");
			break;
		default:
			cout<<"Opcion Invalida."<<endl;
			cout<<endl;
			system("cls");
		}
	}while(opcion!=0);
}
