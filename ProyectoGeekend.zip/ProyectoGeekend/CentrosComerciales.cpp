#include "StdAfx.h"
#include "CentrosComerciales.h"


CentrosComerciales::CentrosComerciales(void)
{
}


CentrosComerciales::~CentrosComerciales(void)
{
}

void CentrosComerciales::CentrosC()
{
	int opcion;

	do{
		cout<<"Bienvenido a la Seccion de Centros Comerciales."<<endl;
		cout<<"Seleccione una de las opciones para ver su informacion."<<endl;
		cout<<endl;
		cout<<"1. Ventura Mall."<<endl;
		cout<<"2. Centro Comercial Las Brisas."<<endl;
		cout<<"3. MALL Santa Cruz."<<endl;
		cout<<"4. Shopping NEVAL."<<endl;
		cout<<"5. Comercial Canhoto."<<endl;
		cout<<"6. Shopping Bolivar."<<endl;
		cout<<"0. Volver."<<endl;
		cin>>opcion;
		system("cls");

		switch(opcion)
		{
		case 1:
			cout<<"___	Ventura Mall	___"<<endl;
			cout<<endl;
			cout<<"Direccion: 4to Anillo e Ingreso al Puente Foianini."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 10:00 a 23:30."<<endl;
			cout<<"Telefono: 3432121."<<endl;
			cout<<endl;
			break;
			system("cls");
		
		case 2:
			cout<<"___	Centro Comercial Las Brisas	___"<<endl;
			cout<<endl;
			cout<<"Direccion: 4to Anillo y Av. Cristo Redentor."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 10:00 a 23:00."<<endl;
			cout<<"Telefono: 3888700."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 3:
			cout<<"___ MALL Santa Cruz	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Isabel La Catolica y Calle Sarah."<<endl;
			cout<<"Horario de Atencion: Lunes a Sabado de 09:00 a 19:00."<<endl;
			cout<<"Telefono: 76894565."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 4:
			cout<<"___	Shopping NEVAL	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Av. Roque Aguilera y 3er Anillo."<<endl;
			cout<<"Horario de Atencion: Todos los dias de 08:00 a 20:00."<<endl;
			cout<<"Telefono: 3563232."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 5:
			cout<<"___	Comercial Canhoto	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Buenos Aires y 1er Anillo."<<endl;
			cout<<"Horario de Atencion: Lunes a Sabado de 09:00 a 20:30."<<endl;
			cout<<"Telefono: 3471600."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 6:
			cout<<"___	Shopping Bolivar	___"<<endl;
			cout<<endl;
			cout<<"Direccion: Calle Bolivar."<<endl;
			cout<<"Horario de Atencion: Lunes a Sabado de 09:00 a 19:00."<<endl;
			cout<<"Telefono: 3471450."<<endl;
			cout<<endl;
			break;
			system("cls");

		case 0:
			cout<<"Volviendo."<<endl;
			system("cls");
			break;

		default:
			cout<<"Opcion Erronea."<<endl;
			cout<<endl;
		}
	}while(opcion!=0);
}
