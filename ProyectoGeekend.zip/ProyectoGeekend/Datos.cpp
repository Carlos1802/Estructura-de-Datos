#include "StdAfx.h"
#include "Datos.h"


Datos::Datos(void)
{
}


Datos::~Datos(void)
{
}
